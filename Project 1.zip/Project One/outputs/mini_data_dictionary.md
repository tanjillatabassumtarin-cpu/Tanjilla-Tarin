# MINI DATA DICTIONARY

| Variable Name | Attribute Description | Scale Unit | Frequency | Collection Source | Notes / Properties |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **company_name** | Official trade identity label | Text String | Constant | Corporate Reports | Square Pharmaceuticals PLC  |
| **ticker or code** | Core exchange identity tag symbol | Text String | Constant | Stock Exchange | SQUAREPHARMA  |
| **date** | Month-end calendar date marker | Date (YYYY-MM-DD) | Monthly | Calendar Object | Calendar-end alignment node  |
| **year** | Current calendar tracking year loop | Integer | Monthly | Derived Date | Range interval: 2020 to 2024  |
| **month** | Current calendar tracking month value | Integer (1 to 12) | Monthly | Derived Date | Range interval: 1 to 12  |
| **month_end_price** | Last trading session close transaction | Float (BDT Currency) | Monthly | File-based CSV Source | Extracted from last active session close  |
| **monthly_stock_return** | Month-on-month percentage returns | Float (Percentage) | Monthly | Calculated Attribute | Derived via percentage yield change formula  |
| **annual_revenue** | Annual gross revenues or sales earnings | Float (BDT Currency) | Annual | Corporate Reports File | Broadcast across months of the same year  |
| **annual_total_assets** | Year-end corporate asset scale valuation | Float (BDT Currency) | Annual | Corporate Reports File | Broadcast across months of the same year  |
| **annual_eps** | Reported annual earnings per share yield | Float (BDT Currency) | Annual | Corporate Reports File | Broadcast across months of the same year  |
| **bd_inflation_annual_pct**| Bangladesh Annual Consumer Price Inflation | Float (Percentage %) | Annual | World Bank API | Indicator reference key: FP.CPI.TOTL.ZG  |
| **bd_gdp_growth_annual_pct**| Bangladesh Annual Net GDP Growth Yield | Float (Percentage %) | Annual | World Bank API | Indicator reference key: NY.GDP.MKTP.KD.ZG  |
